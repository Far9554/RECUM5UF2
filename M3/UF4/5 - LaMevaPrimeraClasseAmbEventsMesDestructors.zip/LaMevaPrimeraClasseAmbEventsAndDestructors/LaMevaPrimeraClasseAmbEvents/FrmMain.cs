﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
#region
//
// Aquesta segona versió del projecte LaMevaPrimeraClasse     
//
#endregion
namespace LaMevaPrimeraClasse
{

    public partial class FrmMain : Form
    {
        List<Image> llImatges = new List<Image>();                          // hi guardarem les imatges dels Angry Birds (els PNG convertits en recursos)
        List<ClAngryBirds> llAngryBirds = new List<ClAngryBirds>();         // hi guardarem les instàncies que anem creant de la classe ClAngryBirds
        List<SoundPlayer> llSons = new List<SoundPlayer>();

        Int32 nocells = 0;                  // comptem el número d'ocells generats

        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            iniAngryBirds();
            iniSons();
            MessageBox.Show("Afegim el destructor a la classe ClAngryBirds i l'eliminem de la llista quan fa una volta", "INFORMACIÓ", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void iniAngryBirds()
        {
            // inicialitzem les imatges a partir dels recursos
            llImatges.Add(LaMevaPrimeraClasse.Properties.Resources.pajarito1);
            llImatges.Add(LaMevaPrimeraClasse.Properties.Resources.pajarito2);
            llImatges.Add(LaMevaPrimeraClasse.Properties.Resources.pajarito3);
            llImatges.Add(LaMevaPrimeraClasse.Properties.Resources.pajarito4);
            llImatges.Add(LaMevaPrimeraClasse.Properties.Resources.pajarito5);
            llImatges.Add(LaMevaPrimeraClasse.Properties.Resources.pajarito6);
        }

        private void iniSons()
        {
            llSons.Add(new SoundPlayer(Application.StartupPath + @"\..\..\01.wav"));
            llSons.Add(new SoundPlayer(Application.StartupPath + @"\..\..\02.wav"));
            llSons.Add(new SoundPlayer(Application.StartupPath + @"\..\..\03.wav"));
        }
        private void FrmMain_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar==((Char) Keys.Escape))
            {
                this.Close();
            }
        }

        private void FrmMain_DoubleClick(object sender, EventArgs e)
        {
            int nImatge = 0;
            int nSo = 0;
            Random R = new Random();

            System.Threading.Thread.Sleep(5); nImatge = R.Next(0, llImatges.Count);
            System.Threading.Thread.Sleep(5); nSo = R.Next(0, llSons.Count);
            nocells++;
            llAngryBirds.Add(new ClAngryBirds(this, llImatges[nImatge],llSons[nSo],nocells));
            llAngryBirds[llAngryBirds.Count - 1].heFetUnaVolta += new EventHandler(unaVoltaMes);
        }

        private void unaVoltaMes(object sender, EventArgs e)
        {
            lbComptaVoltes.Text = (Int32.Parse(lbComptaVoltes.Text) + 1).ToString();
            llAngryBirds.Remove((ClAngryBirds)sender);
            GC.Collect();
        }
    }
}
