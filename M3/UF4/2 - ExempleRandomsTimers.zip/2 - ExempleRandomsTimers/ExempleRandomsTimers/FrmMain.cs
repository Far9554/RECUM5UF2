﻿using System;
#region TIMERS, RANDOMS I ARRAYS
//
//  NOTES SOBRE L'EXEMPLE
//
//      - Aquest exemple mostra algunes de les classes d'objectes que utilitzarem durant el curs:
//      
//              Timers. Rellotges interns que ens permetran realitzar tasques cada cert lapse de temps
//              Random. Classe generadora de números aleatoris.
//              Arrays.     
//
#endregion
using System.Drawing;
using System.Windows.Forms;
using System.Media;

namespace ExempleRandomsTimers
{
    public partial class FrmMain : Form
    {
        String TITOL = "TIMERS, RANDOMS I ARRAYS";     // a diferència del llenguatge C, en C# les cadenes es tracten amb el tipus elemental String i no cal tractar-les com un array de caràcters

        String[] vNoms = new String[] { "Marge", "Homer", "Bart", "Lisa", "Maggie", "Apu", "Barney", "Moe", "Selma", "Patty", "Bob" };      // declarem un array amb 10 noms

        String arxiuOK = Application.StartupPath + @"\..\..\applause.wav";
        String arxiuKO = Application.StartupPath + @"\..\..\boo.wav";

        SoundPlayer soOK;
        SoundPlayer soKO;

        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            this.Text = TITOL + " (" + PintaRellotge() + ")";       // mostrem el títol de la finestra

            lbNom.Text = "";            // buidem l'etiqueta amb el nom

            // activem els Timers
            tmClock.Start();
            tmNom.Start();
            tmNumeros.Start();


            soOK = new SoundPlayer(arxiuOK);         // Instanciem un so que tenim guardat a l'arxiu applause.wav que es troba en una carpeta 1 nivell per sobre de la que conté l'executable del projecte
            soKO = new SoundPlayer(arxiuKO);
        }

        private void TmClock_Tick(object sender, EventArgs e)
        {
            this.Text = TITOL + " (" + PintaRellotge() + ")";
        }

        private void TmNom_Tick(object sender, EventArgs e)
        {
            Random r = new Random();

            System.Threading.Thread.Sleep(5);   // fer un petit sleep aporta dispersió a la successió de números aleatoris
            lbNom.Text = vNoms[r.Next(0, vNoms.Length)];
        }


        private String PintaRellotge()
        {
            String h, m, s;



            h = System.DateTime.Now.Hour.ToString().PadLeft(2, '0');
            m = System.DateTime.Now.Minute.ToString().PadLeft(2, '0');
            s = System.DateTime.Now.Second.ToString().PadLeft(2, '0');
            return (h + ":" + m + ":" + s);
        }

        private void TmNumeros_Tick(object sender, EventArgs e)
        {
            int i = 0;
            int[] vRGB = new int[3];         // declarem un array de 3 enters

            Random r = new Random();

            lbNumeros.Text = "";
            for (i = 0; i < 3; i++)
            {
                vRGB[i] = r.Next() % 256;           // enlloc de generar un número entre 0 i 255 prenem la seqüència del sistema que serà molt més llarga i apliquem l'operació residu sobre 256
                lbNumeros.Text += vRGB[i].ToString();
            }

            this.BackColor = Color.FromArgb(vRGB[0], vRGB[1], vRGB[2]);
        }

        private void BtVerificar_Click(object sender, EventArgs e)
        {
            if ((tbQ1.Text.Trim() == "") || (tbQ2.Text.Trim() == "") || (tbQ3.Text.Trim() == ""))
            {
                MessageBox.Show("Has d'omplir les 3 respostes!!!!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {

                // A TENIR EN COMPTE. Si omplim el TexBox amb valors que no són numèrics peta.
                //                    Ho pots millorar utilitzant TryParse

                if ((Int32.Parse(tbQ1.Text) == 7) && (Int32.Parse(tbQ2.Text) == 7) && (Int32.Parse(tbQ3.Text) == 3))
                {
                    soOK.Play();
                    MessageBox.Show("MOLT BÉÉÉÉÉÉÉÉÉÉÉÉÉÉÉÉÉÉ!!!!!!", "FANTÀSTIC", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                else
                {
                    soKO.Play();
                    MessageBox.Show("UUUUUUUUUUUUUUUUUUUUUUUUUUUUHHHHHHH!!!!!!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }
    }
}
