﻿namespace ExempleRandomsTimers
{
    partial class FrmMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gbQSegons = new System.Windows.Forms.GroupBox();
            this.lbNom = new System.Windows.Forms.Label();
            this.tbQ3 = new System.Windows.Forms.TextBox();
            this.tbQ2 = new System.Windows.Forms.TextBox();
            this.tbQ1 = new System.Windows.Forms.TextBox();
            this.btVerificar = new System.Windows.Forms.Button();
            this.lbQ3 = new System.Windows.Forms.Label();
            this.lbQ2 = new System.Windows.Forms.Label();
            this.lbQ1 = new System.Windows.Forms.Label();
            this.lbObs = new System.Windows.Forms.Label();
            this.lbNumeros = new System.Windows.Forms.Label();
            this.tmClock = new System.Windows.Forms.Timer(this.components);
            this.tmNumeros = new System.Windows.Forms.Timer(this.components);
            this.tmNom = new System.Windows.Forms.Timer(this.components);
            this.gbQSegons.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbQSegons
            // 
            this.gbQSegons.Controls.Add(this.lbNom);
            this.gbQSegons.Controls.Add(this.tbQ3);
            this.gbQSegons.Controls.Add(this.tbQ2);
            this.gbQSegons.Controls.Add(this.tbQ1);
            this.gbQSegons.Controls.Add(this.btVerificar);
            this.gbQSegons.Controls.Add(this.lbQ3);
            this.gbQSegons.Controls.Add(this.lbQ2);
            this.gbQSegons.Controls.Add(this.lbQ1);
            this.gbQSegons.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbQSegons.ForeColor = System.Drawing.Color.SlateGray;
            this.gbQSegons.Location = new System.Drawing.Point(17, 112);
            this.gbQSegons.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gbQSegons.Name = "gbQSegons";
            this.gbQSegons.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.gbQSegons.Size = new System.Drawing.Size(610, 169);
            this.gbQSegons.TabIndex = 6;
            this.gbQSegons.TabStop = false;
            this.gbQSegons.Text = "** Introdueix el número de segons en que canvia cada element **";
            // 
            // lbNom
            // 
            this.lbNom.AutoSize = true;
            this.lbNom.ForeColor = System.Drawing.Color.Tomato;
            this.lbNom.Location = new System.Drawing.Point(409, 128);
            this.lbNom.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbNom.Name = "lbNom";
            this.lbNom.Size = new System.Drawing.Size(53, 16);
            this.lbNom.TabIndex = 8;
            this.lbNom.Text = "lbNom";
            this.lbNom.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tbQ3
            // 
            this.tbQ3.Location = new System.Drawing.Point(343, 125);
            this.tbQ3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tbQ3.MaxLength = 2;
            this.tbQ3.Name = "tbQ3";
            this.tbQ3.Size = new System.Drawing.Size(40, 22);
            this.tbQ3.TabIndex = 7;
            this.tbQ3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbQ2
            // 
            this.tbQ2.Location = new System.Drawing.Point(232, 82);
            this.tbQ2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tbQ2.MaxLength = 2;
            this.tbQ2.Name = "tbQ2";
            this.tbQ2.Size = new System.Drawing.Size(40, 22);
            this.tbQ2.TabIndex = 6;
            this.tbQ2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbQ1
            // 
            this.tbQ1.Location = new System.Drawing.Point(232, 37);
            this.tbQ1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.tbQ1.MaxLength = 2;
            this.tbQ1.Name = "tbQ1";
            this.tbQ1.Size = new System.Drawing.Size(40, 22);
            this.tbQ1.TabIndex = 5;
            this.tbQ1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btVerificar
            // 
            this.btVerificar.Location = new System.Drawing.Point(439, 37);
            this.btVerificar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btVerificar.Name = "btVerificar";
            this.btVerificar.Size = new System.Drawing.Size(148, 74);
            this.btVerificar.TabIndex = 4;
            this.btVerificar.Text = "Verificar";
            this.btVerificar.UseVisualStyleBackColor = true;
            this.btVerificar.Click += new System.EventHandler(this.BtVerificar_Click);
            // 
            // lbQ3
            // 
            this.lbQ3.AutoSize = true;
            this.lbQ3.ForeColor = System.Drawing.Color.SlateGray;
            this.lbQ3.Location = new System.Drawing.Point(45, 128);
            this.lbQ3.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbQ3.Name = "lbQ3";
            this.lbQ3.Size = new System.Drawing.Size(214, 16);
            this.lbQ3.TabIndex = 3;
            this.lbQ3.Text = "El nom mostrat aquí a la dreta";
            this.lbQ3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbQ2
            // 
            this.lbQ2.AutoSize = true;
            this.lbQ2.ForeColor = System.Drawing.Color.SlateGray;
            this.lbQ2.Location = new System.Drawing.Point(45, 85);
            this.lbQ2.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbQ2.Name = "lbQ2";
            this.lbQ2.Size = new System.Drawing.Size(120, 16);
            this.lbQ2.TabIndex = 2;
            this.lbQ2.Text = "El color del fons";
            this.lbQ2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbQ1
            // 
            this.lbQ1.AutoSize = true;
            this.lbQ1.ForeColor = System.Drawing.Color.SlateGray;
            this.lbQ1.Location = new System.Drawing.Point(45, 43);
            this.lbQ1.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbQ1.Name = "lbQ1";
            this.lbQ1.Size = new System.Drawing.Size(77, 16);
            this.lbQ1.TabIndex = 1;
            this.lbQ1.Text = "El número";
            this.lbQ1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbObs
            // 
            this.lbObs.AutoSize = true;
            this.lbObs.ForeColor = System.Drawing.Color.SlateGray;
            this.lbObs.Location = new System.Drawing.Point(200, 324);
            this.lbObs.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbObs.Name = "lbObs";
            this.lbObs.Size = new System.Drawing.Size(262, 14);
            this.lbObs.TabIndex = 5;
            this.lbObs.Text = "fixa\'t en el rellotge del títol de la finestra";
            this.lbObs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbNumeros
            // 
            this.lbNumeros.AutoSize = true;
            this.lbNumeros.ForeColor = System.Drawing.Color.DarkSeaGreen;
            this.lbNumeros.Location = new System.Drawing.Point(20, 51);
            this.lbNumeros.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbNumeros.MinimumSize = new System.Drawing.Size(667, 0);
            this.lbNumeros.Name = "lbNumeros";
            this.lbNumeros.Size = new System.Drawing.Size(667, 14);
            this.lbNumeros.TabIndex = 4;
            this.lbNumeros.Text = "1245";
            this.lbNumeros.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tmClock
            // 
            this.tmClock.Interval = 1000;
            this.tmClock.Tick += new System.EventHandler(this.TmClock_Tick);
            // 
            // tmNumeros
            // 
            this.tmNumeros.Interval = 7000;
            this.tmNumeros.Tick += new System.EventHandler(this.TmNumeros_Tick);
            // 
            // tmNom
            // 
            this.tmNom.Interval = 3000;
            this.tmNom.Tick += new System.EventHandler(this.TmNom_Tick);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(645, 406);
            this.Controls.Add(this.gbQSegons);
            this.Controls.Add(this.lbObs);
            this.Controls.Add(this.lbNumeros);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmMain";
            this.Text = "Randoms i Timers";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.gbQSegons.ResumeLayout(false);
            this.gbQSegons.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbQSegons;
        private System.Windows.Forms.Label lbNom;
        private System.Windows.Forms.TextBox tbQ3;
        private System.Windows.Forms.TextBox tbQ2;
        private System.Windows.Forms.TextBox tbQ1;
        private System.Windows.Forms.Button btVerificar;
        private System.Windows.Forms.Label lbQ3;
        private System.Windows.Forms.Label lbQ2;
        private System.Windows.Forms.Label lbQ1;
        private System.Windows.Forms.Label lbObs;
        private System.Windows.Forms.Label lbNumeros;
        private System.Windows.Forms.Timer tmClock;
        private System.Windows.Forms.Timer tmNumeros;
        private System.Windows.Forms.Timer tmNom;
    }
}

