﻿
namespace Krypto
{
    partial class FrmMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.rtbFtixer = new System.Windows.Forms.RichTextBox();
            this.tbFitxer = new System.Windows.Forms.TextBox();
            this.btExaminar = new System.Windows.Forms.Button();
            this.dlgFile = new System.Windows.Forms.OpenFileDialog();
            this.lbParaules = new System.Windows.Forms.ListBox();
            this.btEncriptarParaula = new System.Windows.Forms.Button();
            this.btDesencriptarParaula = new System.Windows.Forms.Button();
            this.btDesencriptarLinies = new System.Windows.Forms.Button();
            this.btEncriptarLinies = new System.Windows.Forms.Button();
            this.btSave = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rtbFtixer
            // 
            this.rtbFtixer.Location = new System.Drawing.Point(25, 70);
            this.rtbFtixer.Name = "rtbFtixer";
            this.rtbFtixer.Size = new System.Drawing.Size(679, 490);
            this.rtbFtixer.TabIndex = 0;
            this.rtbFtixer.Text = "";
            // 
            // tbFitxer
            // 
            this.tbFitxer.Location = new System.Drawing.Point(25, 26);
            this.tbFitxer.Name = "tbFitxer";
            this.tbFitxer.ReadOnly = true;
            this.tbFitxer.Size = new System.Drawing.Size(679, 26);
            this.tbFitxer.TabIndex = 1;
            // 
            // btExaminar
            // 
            this.btExaminar.Location = new System.Drawing.Point(720, 21);
            this.btExaminar.Name = "btExaminar";
            this.btExaminar.Size = new System.Drawing.Size(131, 34);
            this.btExaminar.TabIndex = 2;
            this.btExaminar.Text = "Examinar...";
            this.btExaminar.UseVisualStyleBackColor = true;
            this.btExaminar.Click += new System.EventHandler(this.btExaminar_Click);
            // 
            // dlgFile
            // 
            this.dlgFile.Title = "Selecciona un fitxer de text";
            // 
            // lbParaules
            // 
            this.lbParaules.FormattingEnabled = true;
            this.lbParaules.ItemHeight = 18;
            this.lbParaules.Location = new System.Drawing.Point(720, 70);
            this.lbParaules.Name = "lbParaules";
            this.lbParaules.Size = new System.Drawing.Size(352, 490);
            this.lbParaules.TabIndex = 3;
            // 
            // btEncriptarParaula
            // 
            this.btEncriptarParaula.Location = new System.Drawing.Point(1091, 70);
            this.btEncriptarParaula.Name = "btEncriptarParaula";
            this.btEncriptarParaula.Size = new System.Drawing.Size(218, 34);
            this.btEncriptarParaula.TabIndex = 4;
            this.btEncriptarParaula.Text = "Encriptar per paraules";
            this.btEncriptarParaula.UseVisualStyleBackColor = true;
            // 
            // btDesencriptarParaula
            // 
            this.btDesencriptarParaula.Location = new System.Drawing.Point(1091, 110);
            this.btDesencriptarParaula.Name = "btDesencriptarParaula";
            this.btDesencriptarParaula.Size = new System.Drawing.Size(218, 34);
            this.btDesencriptarParaula.TabIndex = 5;
            this.btDesencriptarParaula.Text = "Desencriptar per paraules";
            this.btDesencriptarParaula.UseVisualStyleBackColor = true;
            // 
            // btDesencriptarLinies
            // 
            this.btDesencriptarLinies.Location = new System.Drawing.Point(1091, 224);
            this.btDesencriptarLinies.Name = "btDesencriptarLinies";
            this.btDesencriptarLinies.Size = new System.Drawing.Size(218, 34);
            this.btDesencriptarLinies.TabIndex = 7;
            this.btDesencriptarLinies.Text = "Desencriptar per linies";
            this.btDesencriptarLinies.UseVisualStyleBackColor = true;
            // 
            // btEncriptarLinies
            // 
            this.btEncriptarLinies.Location = new System.Drawing.Point(1091, 184);
            this.btEncriptarLinies.Name = "btEncriptarLinies";
            this.btEncriptarLinies.Size = new System.Drawing.Size(218, 34);
            this.btEncriptarLinies.TabIndex = 6;
            this.btEncriptarLinies.Text = "Encriptar per línies";
            this.btEncriptarLinies.UseVisualStyleBackColor = true;
            // 
            // btSave
            // 
            this.btSave.Location = new System.Drawing.Point(1091, 526);
            this.btSave.Name = "btSave";
            this.btSave.Size = new System.Drawing.Size(218, 34);
            this.btSave.TabIndex = 8;
            this.btSave.Text = "Guardar fitxer";
            this.btSave.UseVisualStyleBackColor = true;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.ClientSize = new System.Drawing.Size(1336, 586);
            this.Controls.Add(this.btSave);
            this.Controls.Add(this.btDesencriptarLinies);
            this.Controls.Add(this.btEncriptarLinies);
            this.Controls.Add(this.btDesencriptarParaula);
            this.Controls.Add(this.btEncriptarParaula);
            this.Controls.Add(this.lbParaules);
            this.Controls.Add(this.btExaminar);
            this.Controls.Add(this.tbFitxer);
            this.Controls.Add(this.rtbFtixer);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Krypto";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtbFtixer;
        private System.Windows.Forms.TextBox tbFitxer;
        private System.Windows.Forms.Button btExaminar;
        private System.Windows.Forms.OpenFileDialog dlgFile;
        private System.Windows.Forms.ListBox lbParaules;
        private System.Windows.Forms.Button btEncriptarParaula;
        private System.Windows.Forms.Button btDesencriptarParaula;
        private System.Windows.Forms.Button btDesencriptarLinies;
        private System.Windows.Forms.Button btEncriptarLinies;
        private System.Windows.Forms.Button btSave;
    }
}

