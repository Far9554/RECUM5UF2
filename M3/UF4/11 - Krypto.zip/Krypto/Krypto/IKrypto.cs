﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Krypto
{
    interface IKrypto
    {
        StreamReader fitxer { get; set; }                // és el fitxer sobre el que es volen fer les operacions
        String encriptar(String xs);                // encripta una string amb el mètode d'encriptació que tu inventis

        String desencriptar(String xs);             // desencripta una string amb el mètode d'encriptació que tu inventis

        void encriptarFitxerPerParaules();       // encripta el fitxer paraula a paraula i mantenint els espais

        void desencriptarFitxerPerParaules();       // desencripta el fitxer paraula a paraula i mantenint els espais

        void encriptarFitxerPerLinies();             // encripta el fitxer línia línia mantenint els intros

        void desencriptarFitxerPerLinies();         // desencripta el fitxer línia línia mantenint els intros

        void guardarFitxer();                   // mostra un diàleg que permet guardar el fitxer
    }
}
