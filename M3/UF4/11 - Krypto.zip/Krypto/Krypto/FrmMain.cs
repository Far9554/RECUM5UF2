﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Krypto
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void btExaminar_Click(object sender, EventArgs e)
        {
            dlgFile.InitialDirectory = Environment.SpecialFolder.Desktop.ToString();
            dlgFile.Filter="Fitxers txt (*.txt)|*.txt|Tots els fitxers (*.*)|*.*";
            if (dlgFile.ShowDialog()== DialogResult.OK)
            {
                tbFitxer.Text = dlgFile.FileName;
                mostrarFitxer(tbFitxer.Text);
                mostrarParaules(tbFitxer.Text);
            }
        }

        private void mostrarFitxer(String xnomFitxer)
        {
            StreamReader f = new StreamReader(xnomFitxer);

            rtbFtixer.Text = f.ReadToEnd();
            f.Close();
        }

        private void mostrarParaules(String xnomFitxer)
        {
            StreamReader f = new StreamReader(xnomFitxer);

            lbParaules.Items.Clear();
            while (! f.EndOfStream)
            {
                foreach (String s in f.ReadLine().Split(' '))
                {
                    lbParaules.Items.Add(s);
                }

            }
            f.Close();
        }
    }
}
