﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.Media;

namespace LaMevaPrimeraClasse
{
    class ClAngryBirds
    {
        //
        // --- Propietats ----
        //
        Form fpare { get; set; } = null;                               // ens cal una referència al Formulari pare (contenidor)
        PictureBox imatge { get; set; }  = new PictureBox();           // picturebox on posarem l'angry bird
        SoundPlayer cant { get; set; } = null;                        // hi posarem el so del cant de l'ocell

        // altres variables
        int margeX = 10;
        int margeY = 50;

        // constructor
        public ClAngryBirds(Form xfpare, Image ximatge, SoundPlayer xso)
        {
            fpare = xfpare;                 // assignem el formulari "pare" (el contenidor) a la variable fpare
            imatge.Image = ximatge;
            cant = xso;

            iniPropietatsPictureBox();
            iniEventsPictureBox();
        }

        // altres procediments i funcions
        private void iniPropietatsPictureBox()
        {
            Random R = new Random();
            Point posicio = new Point();

            imatge.Size = new Size(100, 100);
            imatge.SizeMode = PictureBoxSizeMode.StretchImage;
            imatge.BackColor = Color.Transparent;

            // calculem una posició aleatòria per a situar el PictureBox dins el Form pare que n'és el contenidor
            System.Threading.Thread.Sleep(5); posicio.X = R.Next(margeX, fpare.Width - imatge.Width - margeX+1);
            System.Threading.Thread.Sleep(5); posicio.Y = R.Next(margeY, fpare.Height - imatge.Height - margeY+1);
            imatge.Location = posicio;

            fpare.Controls.Add(imatge);        // aquesta operació és necessària per a que el control (el PictureBox) s'incorpori al Form
        }

        private void iniEventsPictureBox()
        {
            imatge.Click += new EventHandler(girarOcell);
            imatge.MouseEnter += new EventHandler(cantar);
        }

        private void girarOcell(object sender, EventArgs e)
        {
            
            imatge.Image.RotateFlip(RotateFlipType.Rotate90FlipXY);
            imatge.Refresh();
        }
        private void cantar(object sender, EventArgs e)
        {
            cant.Play();
        }
    }
}
