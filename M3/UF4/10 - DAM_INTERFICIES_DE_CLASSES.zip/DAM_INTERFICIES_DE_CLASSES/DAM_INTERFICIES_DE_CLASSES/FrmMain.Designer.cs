﻿namespace DAM_INTERFICIES_DE_CLASSES
{
    partial class FrmMain
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.lbEstat = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbEstat
            // 
            this.lbEstat.AutoSize = true;
            this.lbEstat.BackColor = System.Drawing.Color.Black;
            this.lbEstat.ForeColor = System.Drawing.Color.White;
            this.lbEstat.Location = new System.Drawing.Point(0, 503);
            this.lbEstat.Margin = new System.Windows.Forms.Padding(3);
            this.lbEstat.MinimumSize = new System.Drawing.Size(0, 25);
            this.lbEstat.Name = "lbEstat";
            this.lbEstat.Padding = new System.Windows.Forms.Padding(3);
            this.lbEstat.Size = new System.Drawing.Size(46, 25);
            this.lbEstat.TabIndex = 0;
            this.lbEstat.Text = "estat";
            this.lbEstat.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(568, 528);
            this.ControlBox = false;
            this.Controls.Add(this.lbEstat);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "FrmMain";
            this.Text = "    Interfícies de Classes";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.DoubleClick += new System.EventHandler(this.FrmMain_DoubleClick);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.FrmMain_KeyPress);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbEstat;
    }
}

