﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace DAM_INTERFICIES_DE_CLASSES
{
    static class Program
    {
        /// <summary>
        /// Punto de entrada principal para la aplicación.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmMain());
        }
    }
}
