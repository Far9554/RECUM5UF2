﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using DAM_INTERFICIES_DE_CLASSES.CLASSES;

namespace DAM_INTERFICIES_DE_CLASSES
{
    public partial class FrmMain : Form
    {
        List<ClQuadratBlau> llQblau=new List<ClQuadratBlau>();
        List<ClQuadratFucsia> llQfucsia = new List<ClQuadratFucsia>();
        List<ClQuadratVermell> llQvermell=new List<ClQuadratVermell>();


        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            lbEstat.Text = "Doble clic per a generar una figura i <Esc> per a tancar l'aplicació";
            lbEstat.Width = this.Width;
            lbEstat.Height = 50;
            lbEstat.Top = this.Height - lbEstat.Height-80;
        }

        private void FrmMain_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == Convert.ToChar(Keys.Escape))
            {
                this.Close();
            }
        }

        private void FrmMain_DoubleClick(object sender, EventArgs e)
        {
            Random R = new Random();

           // decidim aleatòriament el tipus de quadrat segons color
            System.Threading.Thread.Sleep(2);
            switch ((R.Next() % 3))
            {
                case 0: llQblau.Add(new ClQuadratBlau(this, MousePosition.X, MousePosition.Y - SystemInformation.CaptionHeight));
                     llQblau[llQblau.Count-1].Rebotar(100);
                    break;
                case 1: llQfucsia.Add(new ClQuadratFucsia(this, MousePosition.X, MousePosition.Y - SystemInformation.CaptionHeight));
                    llQfucsia[llQfucsia.Count-1].EncongirExpandir(50);
                    break;
                case 2: llQvermell.Add(new ClQuadratVermell(this, MousePosition.X, MousePosition.Y - SystemInformation.CaptionHeight));
                    llQvermell[llQvermell.Count-1].Rebotar(80);
                    llQvermell[llQvermell.Count - 1].EncongirExpandir(80);
                    break;
            }
        }
    }
}
