﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace DAM_INTERFICIES_DE_CLASSES.CLASSES
{
    //
    // Els quadrats grocs són quadrats Expansors (es van encongint i expandint)
    //
    class ClQuadratVermell : ClRebotador, ClExpansor
    {
        private const int midaMin = 10;             // mida mínima en pixels que pot encongir-se el panell

        private Form frmPare;
        private Panel pnl = new Panel();
        private Timer tmRebotar = new Timer();
        private Timer tmEncongirExpandir = new Timer();

        private int DX = 10;                        // desplaçament de la coordenada X del panell
        private int DY = 10;                        // desplaçament de la coordenada Y del panell

        private int midaMax;                     // mida màxima del panell
        private Point Centre;                    // posició central del panell

        private int factorEscala = -2;          // factor en pixels que s'encongeix o creix el panell

        // propietats
        private int _velocitatRebotar;
        public int velocitatRebotar
        {
            get { return _velocitatRebotar; }
            set { _velocitatRebotar = value; }
        }
        // propietats
        private int _velocitatExpandir;
        public int velocitatExpandir
        {
            get { return _velocitatExpandir; }
            set { _velocitatExpandir = value; }
        }

        public ClQuadratVermell(Form xfrmPare, int xCentre, int yCentre) 
        {
            Random  R = new Random();
            int mida = 0;

            frmPare = xfrmPare;

            // mida aleatòria
            System.Threading.Thread.Sleep(2);
            mida = R.Next(100, xfrmPare.Width / 10);
            midaMax = mida;

            Centre = new Point(xCentre, yCentre);

            // inicialitzem el panell
            pnl.Location = pnl.Location = new Point(xCentre  - mida / 2, Centre.Y - mida / 2);
            pnl.Width = mida;
            pnl.Height = mida;
            pnl.BackColor = Color.Red;
            frmPare.Controls.Add(pnl);

            // inicialitzem els timers posant intervals que siguin números primers per a que no coincideixin els múltiples
            tmRebotar.Interval = 103;
            tmRebotar.Tick += new EventHandler(ferUnTickRebotar);

            tmEncongirExpandir.Interval = 97;
            tmEncongirExpandir.Tick += new EventHandler(ferUnTickEncongirExpandir);
        }

        public void Rebotar(int xvelocitat)
        {
            Random R = new Random();

            // decidim aleatòriament el sentit del desplaçament
            System.Threading.Thread.Sleep(2);
            if ((R.Next() % 2) == 1)
            {
                DX = -DX;
            }
            System.Threading.Thread.Sleep(2);
            if ((R.Next() % 2) == 1)
            {
                DY = -DY;
            }

            tmRebotar.Interval = xvelocitat;
            tmRebotar.Start();
        }

        public void EncongirExpandir(int xvelocitat)
        {
            tmEncongirExpandir.Interval = xvelocitat;
            tmEncongirExpandir.Start();
        }

        private void ferUnTickRebotar(object sender, EventArgs e)
        {
            if ((pnl.Left <= 0) || (pnl.Right >= frmPare.ClientRectangle.Width))
            {
                DX = -DX;
            }
            if ((pnl.Top <= 0) || (pnl.Bottom >= frmPare.ClientRectangle.Height))
            {
                DY = -DY;
            }
            pnl.Location = new Point(pnl.Location.X + DX, pnl.Location.Y + DY);
        }

        private void ferUnTickEncongirExpandir(object sender, EventArgs e)
        {

            pnl.Height = pnl.Height + factorEscala;
            pnl.Width = pnl.Width + factorEscala;
            if ((pnl.Size.Height <= midaMin) || (pnl.Size.Height >= midaMax))
            {
                factorEscala = -factorEscala;
            }

         }
    }
}
