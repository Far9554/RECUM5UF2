﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace DAM_INTERFICIES_DE_CLASSES.CLASSES
{
    //
    // Els quadrats grocs són quadrats Expansors (es van encongint i expandint)
    //
    class ClQuadratFucsia : ClExpansor
    {
        private const int midaMin = 10;             // mida mínima en pixels que pot encongir-se el panell

        private Form frmPare;
        private Panel pnl = new Panel();
        private Timer tm = new Timer();

        private int midaMax;                     // mida màxima del panell
        private Point Centre;                    // posició central del panell

        private int factorEscala = -2;          // factor en pixels que s'encongeix o creix el panell

        // propietats
        private int _velocitatExpandir;
        public int velocitatExpandir
        {
            get { return _velocitatExpandir; }
            set {_velocitatExpandir=value; }
        }

        public ClQuadratFucsia(Form xfrmPare, int xCentre, int yCentre) 
        {
            Random  R = new Random();
            int mida = 0;

            frmPare = xfrmPare;

            // mida aleatòria
            System.Threading.Thread.Sleep(2);
            mida = R.Next(100, xfrmPare.Width / 10);
            midaMax = mida;

            Centre = new Point(xCentre, yCentre);

            // inicialitzem el panell
            pnl.Location = new Point(xCentre  - mida / 2, Centre.Y - mida / 2);
            pnl.Width = mida;
            pnl.Height = mida;
            pnl.BackColor = Color.Fuchsia;
            frmPare.Controls.Add(pnl);

            // inicialitzem el timer
            tm.Tick += new EventHandler(ferUnTick);
        }

        public void EncongirExpandir(int xvelocitat)
        {
            velocitatExpandir = xvelocitat;
            tm.Interval = velocitatExpandir;
            tm.Start();
        }

        private void ferUnTick(object sender, EventArgs e)
        {

            pnl.Height = pnl.Height + factorEscala;
            pnl.Width = pnl.Width + factorEscala;
            if ((pnl.Size.Height <= midaMin) || (pnl.Size.Height >= midaMax))
            {
                factorEscala = -factorEscala;
            }
            pnl.Location = new Point(Centre.X - pnl.Width / 2, Centre.Y - pnl.Height / 2);
        }
    }
}
