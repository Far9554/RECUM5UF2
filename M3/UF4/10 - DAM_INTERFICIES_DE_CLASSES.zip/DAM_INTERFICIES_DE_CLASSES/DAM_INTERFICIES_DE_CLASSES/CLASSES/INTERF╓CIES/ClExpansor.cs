﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAM_INTERFICIES_DE_CLASSES.CLASSES
{
    interface ClExpansor
    {
        int velocitatExpandir
        {
            get;
            set;
        }

        void EncongirExpandir(int xvelocitat);             // mètode que inicia l'encongiment i posterior expansió
    }
}
