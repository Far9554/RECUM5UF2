﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DAM_INTERFICIES_DE_CLASSES.CLASSES
{
    interface ClRebotador
    {
        int velocitatRebotar
        {
            get;
            set;
        }

        void Rebotar(int xvelocitat);             // mètode que inicia els rebots desplaçant el quadrat en una direcció de 45º
    }
}
