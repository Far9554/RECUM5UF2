﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace DAM_INTERFICIES_DE_CLASSES.CLASSES
{
    //
    // Els quadrats blaus són quadrats Rebotadors
    //
    class ClQuadratBlau : ClRebotador
    {
        private Form frmPare;
        private Panel pnl = new Panel();
        private Timer tm = new Timer();

        private int DX = 10;                        // desplaçament de la coordenada X del panell
        private int DY = 10;                        // desplaçament de la coordenada Y del panell

        // propietats
        private int _velocitatRebotar;
        public int velocitatRebotar
        {
            get {
                return _velocitatRebotar; }
            set { _velocitatRebotar = value; }
        }

        public ClQuadratBlau(Form xfrmPare, int xCentre, int yCentre) 
        {
            Random  R = new Random();
            int mida = 0;

            frmPare = xfrmPare;

            // mida aleatòria
            System.Threading.Thread.Sleep(2);
            mida = R.Next(50, xfrmPare.Width / 10);

            // inicialitzem el panell
            pnl.Location = new Point(xCentre- mida/2, yCentre - mida/2);
            pnl.Width = mida;
            pnl.Height = mida;
            pnl.BackColor = Color.Blue;
            frmPare.Controls.Add(pnl);

            // inicialitzem el timer
            tm.Tick += new EventHandler(ferUnTick);
        }

        public void Rebotar(int xvelocitat)
        {
            Random R = new Random();

            // decidim aleatòriament el sentit del desplaçament
            System.Threading.Thread.Sleep(2);
            if ((R.Next() % 2) == 1) {
                DX = -DX;
            }
            System.Threading.Thread.Sleep(2);
            if ((R.Next() % 2) == 1)
            {
                DY = -DY;
            }
            velocitatRebotar = xvelocitat;
            tm.Interval = velocitatRebotar;
            tm.Start();
        }

        private void ferUnTick(object sender, EventArgs e)
        {
            if ((pnl.Left <= 0) || (pnl.Right >= frmPare.ClientRectangle.Width))
            {
                DX = -DX;        
            }
            if ((pnl.Top <= 0) || (pnl.Bottom >= frmPare.ClientRectangle.Height))
            {
                DY = -DY;
            }
            pnl.Location = new Point(pnl.Location.X + DX, pnl.Location.Y + DY);
        }
    }
}
