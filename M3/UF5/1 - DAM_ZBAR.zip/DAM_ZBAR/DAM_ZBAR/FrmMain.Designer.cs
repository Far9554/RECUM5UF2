﻿namespace DAM_ZBar
{
    partial class FrmMain
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btOpen = new System.Windows.Forms.Button();
            this.imgQR = new System.Windows.Forms.PictureBox();
            this.tbQR = new System.Windows.Forms.TextBox();
            this.btCrearQR = new System.Windows.Forms.Button();
            this.lbText = new System.Windows.Forms.Label();
            this.lbOpen = new System.Windows.Forms.Label();
            this.btSave = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.imgQR)).BeginInit();
            this.SuspendLayout();
            // 
            // btOpen
            // 
            this.btOpen.BackColor = System.Drawing.Color.YellowGreen;
            this.btOpen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btOpen.Location = new System.Drawing.Point(222, 436);
            this.btOpen.Name = "btOpen";
            this.btOpen.Size = new System.Drawing.Size(105, 36);
            this.btOpen.TabIndex = 0;
            this.btOpen.Text = "Examinar...";
            this.btOpen.UseVisualStyleBackColor = false;
            this.btOpen.Click += new System.EventHandler(this.btOpen_Click);
            // 
            // imgQR
            // 
            this.imgQR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imgQR.Location = new System.Drawing.Point(12, 70);
            this.imgQR.Name = "imgQR";
            this.imgQR.Size = new System.Drawing.Size(350, 350);
            this.imgQR.TabIndex = 1;
            this.imgQR.TabStop = false;
            // 
            // tbQR
            // 
            this.tbQR.Location = new System.Drawing.Point(12, 42);
            this.tbQR.Name = "tbQR";
            this.tbQR.Size = new System.Drawing.Size(494, 22);
            this.tbQR.TabIndex = 2;
            // 
            // btCrearQR
            // 
            this.btCrearQR.BackColor = System.Drawing.Color.YellowGreen;
            this.btCrearQR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCrearQR.Location = new System.Drawing.Point(401, 70);
            this.btCrearQR.Name = "btCrearQR";
            this.btCrearQR.Size = new System.Drawing.Size(105, 33);
            this.btCrearQR.TabIndex = 3;
            this.btCrearQR.Text = "Crear QR";
            this.btCrearQR.UseVisualStyleBackColor = false;
            this.btCrearQR.Click += new System.EventHandler(this.btCrearQR_Click);
            // 
            // lbText
            // 
            this.lbText.AutoSize = true;
            this.lbText.Location = new System.Drawing.Point(13, 23);
            this.lbText.Name = "lbText";
            this.lbText.Size = new System.Drawing.Size(121, 14);
            this.lbText.TabIndex = 4;
            this.lbText.Text = "Introdueix un text";
            // 
            // lbOpen
            // 
            this.lbOpen.AutoSize = true;
            this.lbOpen.Location = new System.Drawing.Point(15, 447);
            this.lbOpen.Name = "lbOpen";
            this.lbOpen.Size = new System.Drawing.Size(201, 14);
            this.lbOpen.TabIndex = 5;
            this.lbOpen.Text = "Selecciona un arxiu amb un QR";
            // 
            // btSave
            // 
            this.btSave.BackColor = System.Drawing.Color.Crimson;
            this.btSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSave.ForeColor = System.Drawing.Color.White;
            this.btSave.Location = new System.Drawing.Point(401, 387);
            this.btSave.Name = "btSave";
            this.btSave.Size = new System.Drawing.Size(105, 33);
            this.btSave.TabIndex = 6;
            this.btSave.Text = "Guardar";
            this.btSave.UseVisualStyleBackColor = false;
            this.btSave.Click += new System.EventHandler(this.btSave_Click);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 495);
            this.Controls.Add(this.btSave);
            this.Controls.Add(this.lbOpen);
            this.Controls.Add(this.lbText);
            this.Controls.Add(this.btCrearQR);
            this.Controls.Add(this.tbQR);
            this.Controls.Add(this.imgQR);
            this.Controls.Add(this.btOpen);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ZXing Scan";
            ((System.ComponentModel.ISupportInitialize)(this.imgQR)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btOpen;
        private System.Windows.Forms.PictureBox imgQR;
        private System.Windows.Forms.TextBox tbQR;
        private System.Windows.Forms.Button btCrearQR;
        private System.Windows.Forms.Label lbText;
        private System.Windows.Forms.Label lbOpen;
        private System.Windows.Forms.Button btSave;
    }
}

