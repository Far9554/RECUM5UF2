﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using QRCoder;          // hem instal·lat el paquet (NuGet) QR Coder de Raffael Herrmann
using ZXing;            // hem instal·lat el paquet (NuGet) ZXing.Net

namespace DAM_ZBar
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }


        private void btOpen_Click(object sender, EventArgs e)
        {
            Bitmap bmp;
            BarcodeReader lector = new BarcodeReader { AutoRotate = true };
            OpenFileDialog dlg = new OpenFileDialog();

            dlg.Title = "Selecciona un arxiu QR";
            dlg.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            dlg.Filter = "Arxius png (*.png)|*.png|Arxius jpg (*.jpg)|*.jpg|Arxius bmp (*.bmp)|*.bmp|Tots els arxius (*.*)|*.*";
            if (dlg.ShowDialog() == DialogResult.OK)
            {
                imgQR.Load(dlg.FileName);
                imgQR.SizeMode = PictureBoxSizeMode.StretchImage;

                try
                {
                    bmp = new Bitmap(imgQR.Image);
                    tbQR.Text = "";

                    var l = lector.Decode(bmp);

                    if (l != null)
                    {
                        tbQR.Text = lector.Decode(bmp).Text;
                    }
                    else
                    {
                        MessageBox.Show("Això no és un QR");
                    }
                }
                catch (Exception excp)
                {
                    MessageBox.Show(excp.Message, "Excepció", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }

        }

        private void btCrearQR_Click(object sender, EventArgs e)
        {
            if (tbQR.Text.Trim() == "")
            {
                MessageBox.Show("Has d'introduir un text per a generar el QR", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                QRCodeGenerator qr = new QRCodeGenerator();
                QRCodeData qrData = qr.CreateQrCode(tbQR.Text.Trim(), QRCodeGenerator.ECCLevel.Q);
                QRCode qrCode = new QRCode(qrData);
                Bitmap qrCodeImage = qrCode.GetGraphic(10);

                imgQR.Image = qrCodeImage;
                imgQR.SizeMode = PictureBoxSizeMode.StretchImage;
            }
        }

        private void btSave_Click(object sender, EventArgs e)
        {
            SaveFileDialog dlg = new SaveFileDialog();

            if (imgQR.Image != null)
            {
                dlg.Title = "Guardar el codi QR en un arxiu";
                dlg.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                dlg.Filter = "Arxius png (*.png)|*.png|Arxius jpg (*.jpg)|*.jpg|Arxius bmp (*.bmp)|*.bmp|Tots els arxius (*.*)|*.*";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    imgQR.Image.Save(dlg.FileName);
                }
            }
        }
    }
}
