﻿namespace DAM_Webcam_Aforge
{
    partial class FrmMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.cbCameres = new System.Windows.Forms.ComboBox();
            this.lbCameres = new System.Windows.Forms.Label();
            this.btOnOff = new System.Windows.Forms.Button();
            this.pbFotograma = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbFotograma)).BeginInit();
            this.SuspendLayout();
            // 
            // cbCameres
            // 
            this.cbCameres.FormattingEnabled = true;
            this.cbCameres.Location = new System.Drawing.Point(182, 32);
            this.cbCameres.Name = "cbCameres";
            this.cbCameres.Size = new System.Drawing.Size(378, 28);
            this.cbCameres.TabIndex = 0;
            // 
            // lbCameres
            // 
            this.lbCameres.AutoSize = true;
            this.lbCameres.BackColor = System.Drawing.Color.Sienna;
            this.lbCameres.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbCameres.ForeColor = System.Drawing.Color.White;
            this.lbCameres.Location = new System.Drawing.Point(26, 32);
            this.lbCameres.MinimumSize = new System.Drawing.Size(150, 2);
            this.lbCameres.Name = "lbCameres";
            this.lbCameres.Padding = new System.Windows.Forms.Padding(3);
            this.lbCameres.Size = new System.Drawing.Size(150, 28);
            this.lbCameres.TabIndex = 1;
            this.lbCameres.Text = "Càmeres";
            // 
            // btOnOff
            // 
            this.btOnOff.BackColor = System.Drawing.Color.LimeGreen;
            this.btOnOff.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btOnOff.Location = new System.Drawing.Point(566, 24);
            this.btOnOff.Name = "btOnOff";
            this.btOnOff.Size = new System.Drawing.Size(133, 43);
            this.btOnOff.TabIndex = 2;
            this.btOnOff.Text = "On";
            this.btOnOff.UseVisualStyleBackColor = false;
            this.btOnOff.Click += new System.EventHandler(this.btOnOff_Click);
            // 
            // pbFotograma
            // 
            this.pbFotograma.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbFotograma.Image = global::DAM_Webcam_Aforge.Properties.Resources.camera_off;
            this.pbFotograma.InitialImage = global::DAM_Webcam_Aforge.Properties.Resources.camera_off;
            this.pbFotograma.Location = new System.Drawing.Point(26, 79);
            this.pbFotograma.Name = "pbFotograma";
            this.pbFotograma.Size = new System.Drawing.Size(445, 452);
            this.pbFotograma.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pbFotograma.TabIndex = 3;
            this.pbFotograma.TabStop = false;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(736, 560);
            this.Controls.Add(this.pbFotograma);
            this.Controls.Add(this.btOnOff);
            this.Controls.Add(this.lbCameres);
            this.Controls.Add(this.cbCameres);
            this.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Webcam";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbFotograma)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbCameres;
        private System.Windows.Forms.Label lbCameres;
        private System.Windows.Forms.Button btOnOff;
        private System.Windows.Forms.PictureBox pbFotograma;
    }
}

