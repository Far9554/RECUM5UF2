﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using AForge.Video;                 // hem instal·lat els paquets (Nuget) Aforge, Aforge.Video i Aforge.Video.DirectShow
using AForge.Video.DirectShow;

namespace DAM_Webcam_Aforge
{
    public partial class FrmMain : Form
    {
        FilterInfoCollection filtreCameres;
        VideoCaptureDevice kam = null;

        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            getCameres();
        }

        private void getCameres()
        {
            filtreCameres = new FilterInfoCollection(FilterCategory.VideoInputDevice);
            foreach (FilterInfo k in filtreCameres)
            {
                cbCameres.Items.Add(k.Name);
                cbCameres.SelectedIndex = 0;
            }
            btOnOff.Visible = (filtreCameres.Count > 0);
        }

        private void btOnOff_Click(object sender, EventArgs e)
        {
            if (btOnOff.Text=="On")
            {
                btOnOff.Text = "Off";
                btOnOff.BackColor = Color.Red;
                iniciarKam();
                cbCameres.Enabled = false;

            } else
            {
                btOnOff.Text = "On";
                btOnOff.BackColor = Color.LimeGreen;
                aturarKam();
                cbCameres.Enabled = true;
            }
        }

        private void nouFotograma(object sender, NewFrameEventArgs e)
        {
            pbFotograma.Image = (Image) e.Frame.Clone();            // AForge requereix fer una còpia (un clon) perquè 
                                                                    // si posem directament el Frame tenim problemes d'accés a memòria
                                                                    // solapant-se un fotograma amb el següent
        }

        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            aturarKam();
        }

        private void iniciarKam()
        {
            if (cbCameres.SelectedIndex >= 0)
            {
                kam = new VideoCaptureDevice(filtreCameres[cbCameres.SelectedIndex].MonikerString);
                kam.NewFrame += nouFotograma;
                kam.Start();
            }
        }

        private void aturarKam()
        {
            if ((kam != null) && (kam.IsRunning))
            {
                kam.Stop();
                kam = null;
            }
            pbFotograma.Image = Properties.Resources.camera_off;
        }
    }
}
