﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAM_NewtonSoftJSON
{
    internal class ClMovies
    {
        public string titol { get; set; }
        public int anyEstrena { get; set; }
        public List<ClPremi> llPremis { get; set; }
    }

    internal class ClPremi
    {
        public string festival { get; set; }
        public string edicio { get; set; }
        public int anyFestival { get; set; }
        public string premi { get; set; }
    }
}
