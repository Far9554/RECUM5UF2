﻿
namespace DAM_NewtonSoftJSON
{
    partial class FrmMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btExaminar = new System.Windows.Forms.Button();
            this.tbFitxer = new System.Windows.Forms.TextBox();
            this.tbJson = new System.Windows.Forms.TextBox();
            this.dlgFitxer = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // btExaminar
            // 
            this.btExaminar.Location = new System.Drawing.Point(27, 31);
            this.btExaminar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btExaminar.Name = "btExaminar";
            this.btExaminar.Size = new System.Drawing.Size(149, 49);
            this.btExaminar.TabIndex = 0;
            this.btExaminar.Text = "Examinar...";
            this.btExaminar.UseVisualStyleBackColor = true;
            this.btExaminar.Click += new System.EventHandler(this.btExaminar_Click);
            // 
            // tbFitxer
            // 
            this.tbFitxer.Location = new System.Drawing.Point(183, 31);
            this.tbFitxer.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbFitxer.Multiline = true;
            this.tbFitxer.Name = "tbFitxer";
            this.tbFitxer.Size = new System.Drawing.Size(465, 656);
            this.tbFitxer.TabIndex = 1;
            // 
            // tbJson
            // 
            this.tbJson.Location = new System.Drawing.Point(666, 31);
            this.tbJson.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbJson.Multiline = true;
            this.tbJson.Name = "tbJson";
            this.tbJson.Size = new System.Drawing.Size(465, 656);
            this.tbJson.TabIndex = 2;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1150, 700);
            this.Controls.Add(this.tbJson);
            this.Controls.Add(this.tbFitxer);
            this.Controls.Add(this.btExaminar);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FrmMain";
            this.Text = "NewtonSoft - JSON";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btExaminar;
        private System.Windows.Forms.TextBox tbFitxer;
        private System.Windows.Forms.TextBox tbJson;
        private System.Windows.Forms.OpenFileDialog dlgFitxer;
    }
}

