﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Newtonsoft.Json;
using System.Web.Script.Serialization;

namespace DAM_NewtonSoftJSON
{
    public partial class FrmMain : Form
    {
        List<ClMovies> llPelis = new List<ClMovies>();

        public FrmMain()
        {
            InitializeComponent();
        }

        private void btExaminar_Click(object sender, EventArgs e)
        { 
            if (dlgFitxer.ShowDialog()== DialogResult.OK)
            {
                carregarFitxer();
                carregarJson();
            }
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            dlgFitxer.InitialDirectory = Application.StartupPath;
        }

        private void carregarFitxer()
        {
            StreamReader sR = new StreamReader(dlgFitxer.FileName);

            tbFitxer.Text = sR.ReadToEnd();
            sR.Close();
        }

        private void carregarJson()
        {

            // deserialitzem des d'un fitxer
            StreamReader sR = new StreamReader(dlgFitxer.FileName);
            using (JsonReader Reader = new JsonTextReader(sR))
            {
                JsonSerializer Serializer = new JsonSerializer();
                llPelis = Serializer.Deserialize<List<ClMovies>>(Reader);
            }

            tbJson.Text = "";
            foreach (ClMovies p in llPelis)
            {
                tbJson.Text += p.titol + " (" + p.anyEstrena.ToString() + ")" + Environment.NewLine;
                foreach (ClPremi pr in p.llPremis)
                {
                    tbJson.Text += "            " + pr.edicio.ToString()+" "+pr.festival + " - " + pr.premi+Environment.NewLine;
                }
                tbJson.Text+=Environment.NewLine;
            }
           
        }
    }
}
