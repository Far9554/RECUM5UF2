﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Amazon.Rekognition;
using Amazon.Rekognition.Model;
using Newtonsoft.Json;

namespace AWSRekognition
{
    //
    //      https://docs.aws.amazon.com/sdkfornet/v3/apidocs/
    //      https://docs.aws.amazon.com/sdkfornet/v3/apidocs/items/Rekognition/NRekognition.html
    //      https://docs.aws.amazon.com/sdkfornet/v3/apidocs/items/Rekognition/NRekognitionModel.html
    //
    public partial class FrmMain : Form
    {
        String awsKey = "";
        String awsSecret = "";
        String awsToken = "+dpAxa+JcmnX139c6J3Us+zf8NKl6kadLaiNtYb73isOOjsIzx4sIbBb4A6Q4fSsGee3UKfpz8ChPssk5xcRy0k/fFijM6/H0+dM1PHVjjS84HrjjhTJK68Pvv83LAy6QPUAnomdx6l1hSPAu3hCy5UStx4aBYnAD/uJy/wlCzn0PRPrrQ6TwwdCo/bO3bUl2TvJkqk8542f7/UWO+ouBeVGZc1ACa1pwgE1LQRWj/GLwfQi2e+NyAnNIojczemgYyLeYDt13p7MlPliBgwKvJxRGMJDScy42K8xT+da0uOHFBsXauf2NZ8x8kavhdeg==";

        List<Rectangle> llRectangles = new List<Rectangle>();
        List<System.Windows.Forms.Label> llEtiquetes = new List<System.Windows.Forms.Label>();
        List<Color> llColors = new List<Color>();
        public FrmMain()
        {
            InitializeComponent();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            tabPestanyes.Size = this.Size;
            llTextos.Height = tabPestanyes.Bottom-llTextos.Top-80;
            tbJson.Height = tabPestanyes.Bottom-tbJson.Top - 88;

            iniColors();
            pbImatge.Paint += new PaintEventHandler(pintarRectangles);

        }

        private void iniColors()
        {
            llColors.Add(Color.White);
            llColors.Add(Color.Red);
            llColors.Add(Color.Green);
            llColors.Add(Color.Orange);
            llColors.Add(Color.Blue);
            llColors.Add(Color.Magenta);
            llColors.Add(Color.Black);
            llColors.Add(Color.GreenYellow);
            llColors.Add(Color.Silver);
            llColors.Add(Color.Aquamarine);
            llColors.Add(Color.Brown);
            llColors.Add(Color.Gold);
            llColors.Add(Color.Chartreuse);
            llColors.Add(Color.Cyan);
            llColors.Add(Color.AliceBlue);
            llColors.Add(Color.DarkGoldenrod);
            llColors.Add(Color.Lavender);
            llColors.Add(Color.LemonChiffon);
            llColors.Add(Color.Fuchsia);
            llColors.Add(Color.Maroon);
        }
        private void btExaminar_Click(object sender, EventArgs e)
        {
            if (dlgImatge.ShowDialog()== DialogResult.OK)
            {
                iniLlistes();
                pbImatge.Image = null;
                pbImatge.Image = new Bitmap(dlgImatge.FileName);               
                pbImatge.Refresh();
            } 
        }
        private void btDetectar_Click(object sender, EventArgs e)
        {
            if (pbImatge.Image != null)
            {
                Cursor = Cursors.WaitCursor;

                if (rdTextos.Checked)
                {
                    DetectarTextos(new Bitmap(pbImatge.Image));
                }
                else
                {
                    if (rdEmocions.Checked)
                    {
                        DetectarEmocions(new Bitmap(pbImatge.Image),false);
                    }
                    else
                    {
                        if (rdFamosos.Checked)
                        {
                            DetectarEmocions(new Bitmap(pbImatge.Image),true);
                        }
                    }

                }
            }
            Cursor = Cursors.Default;
        }

        private void iniLlistes()
        {
            llRectangles.Clear();
            foreach (System.Windows.Forms.Label l in llEtiquetes)
            {
                pbImatge.Controls.Remove(l);
            }
            llEtiquetes.Clear();
            llTextos.Items.Clear();
            tbJson.Text = "";
        }

        void DetectarTextos(Bitmap xImatge)
        {
            iniLlistes();
            try
            {
                ImageConverter convertidor = new ImageConverter();
                Byte[] imatgeEnBytes = (Byte[]) convertidor.ConvertTo(xImatge, typeof(byte[]));
                
                Amazon.Rekognition.Model.Image imatgeAWS = new Amazon.Rekognition.Model.Image();
                AmazonRekognitionClient clientAWSRekognition = new AmazonRekognitionClient(awsKey, awsSecret, awsToken, Amazon.RegionEndpoint.USEast1);

                DetectTextRequest textosDetectats = new DetectTextRequest();

                imatgeAWS.Bytes = new MemoryStream(imatgeEnBytes);

                textosDetectats.Image = imatgeAWS;

                var deteccions = clientAWSRekognition.DetectText(textosDetectats);
                if (deteccions.TextDetections.Count > 0)
                {
                    var jsonDeteccions = JsonConvert.SerializeObject(deteccions.TextDetections);
                    tbJson.Text = jsonDeteccions;

                    foreach (TextDetection t in deteccions.TextDetections)
                    {
                        llTextos.Items.Add(t.DetectedText);
                        afegirRectangle(pbImatge.Image, t.Geometry.BoundingBox);
                    }
                    pbImatge.SendToBack();
                    pbImatge.Refresh();
                }
            }
            catch (Exception excp)
            {
                MessageBox.Show(excp.Message);
            }
        }

        private void DetectarEmocions(Bitmap xImatge, Boolean celebrities)
        {
            Int32 n = 0;

            iniLlistes();
            try
            {
                ImageConverter convertidor = new ImageConverter();
                Byte[] imatgeEnBytes = (Byte[])convertidor.ConvertTo(xImatge, typeof(byte[]));

                Amazon.Rekognition.Model.Image imatgeAWS = new Amazon.Rekognition.Model.Image();
                AmazonRekognitionClient clientAWSRekognition = new AmazonRekognitionClient(awsKey, awsSecret, awsToken, Amazon.RegionEndpoint.USEast1);
                RecognizeCelebritiesRequest peticioReconeixementCelebritats = new RecognizeCelebritiesRequest();


                CelebrityRecognition celebritatsDetectades = new CelebrityRecognition();

                imatgeAWS.Bytes = new MemoryStream(imatgeEnBytes);

                peticioReconeixementCelebritats.Image = imatgeAWS;

                RecognizeCelebritiesResponse respostaReconeixementCelebritats = clientAWSRekognition.RecognizeCelebrities(peticioReconeixementCelebritats);

                if (celebrities)
                {
                    var jsonDeteccions = JsonConvert.SerializeObject(respostaReconeixementCelebritats.CelebrityFaces);
                    tbJson.Text = jsonDeteccions;

                    foreach (Celebrity c in respostaReconeixementCelebritats.CelebrityFaces)
                    {
                        afegirRectangle(pbImatge.Image, c.Face.BoundingBox);
                        llTextos.Items.Add(n.ToString());
                        foreach (Emotion e in c.Face.Emotions)
                        {
                            llTextos.Items.Add(e.Type.ToString() + " - " + e.Confidence.ToString() + "%");
                        }
                        llTextos.Items.Add("");
                        n++;
                    }
                }
                else
                {
                    foreach (ComparedFace c in respostaReconeixementCelebritats.UnrecognizedFaces)
                    {
                        afegirRectangle(pbImatge.Image, c.BoundingBox);
                        llTextos.Items.Add(n.ToString());
                        foreach (Emotion e in c.Emotions)
                        {
                            llTextos.Items.Add(e.Type.ToString() + " - " + e.Confidence.ToString() + "%");
                        }
                        llTextos.Items.Add("");
                        n++;
                    }
                }
                pbImatge.Refresh();

            }
            catch (Exception excp)
            {
                MessageBox.Show(excp.Message);
            }
        }


        private void afegirRectangle(System.Drawing.Image img, BoundingBox xr)
        {
            Int32 l, t, w, h;

            l = (Int32) Math.Round(img.Width * xr.Left,0);
            t = (Int32)Math.Round(img.Height * xr.Top, 0);
            w = (Int32)Math.Round(img.Width * xr.Width, 0);
            h = (Int32)Math.Round(img.Height * xr.Height, 0);

            llRectangles.Add(new Rectangle(l,t,w,h));
        }

        private void pintarRectangles(object sender, PaintEventArgs e)
        {
            Int32 n = 0;

            foreach (Rectangle r in llRectangles) {
                e.Graphics.DrawRectangle(new Pen(llColors[n % llColors.Count], 2), r);

                if ((rdEmocions.Checked) || (rdFamosos.Checked))
                {
                    llEtiquetes.Add(new System.Windows.Forms.Label());
                    llEtiquetes[llEtiquetes.Count - 1].Text = n.ToString();
                    llEtiquetes[llEtiquetes.Count - 1].ForeColor = Color.Black;
                    llEtiquetes[llEtiquetes.Count - 1].Font = new Font("Verdana", 12, FontStyle.Bold);
                    llEtiquetes[llEtiquetes.Count - 1].AutoSize = true;
                    llEtiquetes[llEtiquetes.Count - 1].Location = new System.Drawing.Point(r.Left, r.Top - llEtiquetes[llEtiquetes.Count - 1].Height - 5);
                    pbImatge.Controls.Add(llEtiquetes[llEtiquetes.Count - 1]);
                }
                n++;
            }
        }
    }
}
