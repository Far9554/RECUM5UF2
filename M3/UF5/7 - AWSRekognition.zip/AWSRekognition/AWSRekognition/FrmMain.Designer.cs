﻿
namespace AWSRekognition
{
    partial class FrmMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btExaminar = new System.Windows.Forms.Button();
            this.pbImatge = new System.Windows.Forms.PictureBox();
            this.dlgImatge = new System.Windows.Forms.OpenFileDialog();
            this.llTextos = new System.Windows.Forms.ListBox();
            this.lb = new System.Windows.Forms.Label();
            this.lbJson = new System.Windows.Forms.Label();
            this.tbJson = new System.Windows.Forms.TextBox();
            this.tabPestanyes = new System.Windows.Forms.TabControl();
            this.tabImatge = new System.Windows.Forms.TabPage();
            this.rdFamosos = new System.Windows.Forms.RadioButton();
            this.btDetectar = new System.Windows.Forms.Button();
            this.rdEmocions = new System.Windows.Forms.RadioButton();
            this.rdTextos = new System.Windows.Forms.RadioButton();
            this.tabResultats = new System.Windows.Forms.TabPage();
            ((System.ComponentModel.ISupportInitialize)(this.pbImatge)).BeginInit();
            this.tabPestanyes.SuspendLayout();
            this.tabImatge.SuspendLayout();
            this.tabResultats.SuspendLayout();
            this.SuspendLayout();
            // 
            // btExaminar
            // 
            this.btExaminar.BackColor = System.Drawing.Color.PaleGoldenrod;
            this.btExaminar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btExaminar.Location = new System.Drawing.Point(7, 6);
            this.btExaminar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btExaminar.Name = "btExaminar";
            this.btExaminar.Size = new System.Drawing.Size(168, 35);
            this.btExaminar.TabIndex = 0;
            this.btExaminar.Text = "Seleccionar imatge...";
            this.btExaminar.UseVisualStyleBackColor = false;
            this.btExaminar.Click += new System.EventHandler(this.btExaminar_Click);
            // 
            // pbImatge
            // 
            this.pbImatge.Location = new System.Drawing.Point(7, 47);
            this.pbImatge.Name = "pbImatge";
            this.pbImatge.Size = new System.Drawing.Size(416, 438);
            this.pbImatge.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbImatge.TabIndex = 1;
            this.pbImatge.TabStop = false;
            // 
            // llTextos
            // 
            this.llTextos.FormattingEnabled = true;
            this.llTextos.ItemHeight = 18;
            this.llTextos.Location = new System.Drawing.Point(6, 35);
            this.llTextos.Name = "llTextos";
            this.llTextos.Size = new System.Drawing.Size(380, 688);
            this.llTextos.TabIndex = 2;
            // 
            // lb
            // 
            this.lb.AutoSize = true;
            this.lb.BackColor = System.Drawing.Color.NavajoWhite;
            this.lb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb.Location = new System.Drawing.Point(6, 10);
            this.lb.MinimumSize = new System.Drawing.Size(380, 2);
            this.lb.Name = "lb";
            this.lb.Padding = new System.Windows.Forms.Padding(3);
            this.lb.Size = new System.Drawing.Size(380, 26);
            this.lb.TabIndex = 3;
            this.lb.Text = "textos detectats";
            this.lb.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lbJson
            // 
            this.lbJson.AutoSize = true;
            this.lbJson.BackColor = System.Drawing.Color.NavajoWhite;
            this.lbJson.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbJson.Location = new System.Drawing.Point(392, 10);
            this.lbJson.MinimumSize = new System.Drawing.Size(800, 2);
            this.lbJson.Name = "lbJson";
            this.lbJson.Padding = new System.Windows.Forms.Padding(3);
            this.lbJson.Size = new System.Drawing.Size(800, 26);
            this.lbJson.TabIndex = 4;
            this.lbJson.Text = "Json";
            this.lbJson.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tbJson
            // 
            this.tbJson.Location = new System.Drawing.Point(392, 35);
            this.tbJson.Multiline = true;
            this.tbJson.Name = "tbJson";
            this.tbJson.ReadOnly = true;
            this.tbJson.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.tbJson.Size = new System.Drawing.Size(800, 704);
            this.tbJson.TabIndex = 5;
            // 
            // tabPestanyes
            // 
            this.tabPestanyes.Controls.Add(this.tabImatge);
            this.tabPestanyes.Controls.Add(this.tabResultats);
            this.tabPestanyes.Location = new System.Drawing.Point(12, 12);
            this.tabPestanyes.Name = "tabPestanyes";
            this.tabPestanyes.SelectedIndex = 0;
            this.tabPestanyes.Size = new System.Drawing.Size(1703, 767);
            this.tabPestanyes.TabIndex = 6;
            // 
            // tabImatge
            // 
            this.tabImatge.AutoScroll = true;
            this.tabImatge.BackColor = System.Drawing.Color.Transparent;
            this.tabImatge.Controls.Add(this.rdFamosos);
            this.tabImatge.Controls.Add(this.btDetectar);
            this.tabImatge.Controls.Add(this.rdEmocions);
            this.tabImatge.Controls.Add(this.rdTextos);
            this.tabImatge.Controls.Add(this.pbImatge);
            this.tabImatge.Controls.Add(this.btExaminar);
            this.tabImatge.Location = new System.Drawing.Point(4, 27);
            this.tabImatge.Name = "tabImatge";
            this.tabImatge.Padding = new System.Windows.Forms.Padding(3);
            this.tabImatge.Size = new System.Drawing.Size(1695, 736);
            this.tabImatge.TabIndex = 0;
            this.tabImatge.Text = "imatge";
            // 
            // rdFamosos
            // 
            this.rdFamosos.AutoSize = true;
            this.rdFamosos.Location = new System.Drawing.Point(440, 15);
            this.rdFamosos.Name = "rdFamosos";
            this.rdFamosos.Size = new System.Drawing.Size(102, 22);
            this.rdFamosos.TabIndex = 5;
            this.rdFamosos.Text = "celebrities";
            this.rdFamosos.UseVisualStyleBackColor = true;
            // 
            // btDetectar
            // 
            this.btDetectar.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btDetectar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDetectar.ForeColor = System.Drawing.Color.White;
            this.btDetectar.Location = new System.Drawing.Point(583, 6);
            this.btDetectar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btDetectar.Name = "btDetectar";
            this.btDetectar.Size = new System.Drawing.Size(168, 35);
            this.btDetectar.TabIndex = 4;
            this.btDetectar.Text = "Detectar";
            this.btDetectar.UseVisualStyleBackColor = false;
            this.btDetectar.Click += new System.EventHandler(this.btDetectar_Click);
            // 
            // rdEmocions
            // 
            this.rdEmocions.AutoSize = true;
            this.rdEmocions.Location = new System.Drawing.Point(311, 14);
            this.rdEmocions.Name = "rdEmocions";
            this.rdEmocions.Size = new System.Drawing.Size(101, 22);
            this.rdEmocions.TabIndex = 3;
            this.rdEmocions.Text = "emocions";
            this.rdEmocions.UseVisualStyleBackColor = true;
            // 
            // rdTextos
            // 
            this.rdTextos.AutoSize = true;
            this.rdTextos.Checked = true;
            this.rdTextos.Location = new System.Drawing.Point(204, 15);
            this.rdTextos.Name = "rdTextos";
            this.rdTextos.Size = new System.Drawing.Size(77, 22);
            this.rdTextos.TabIndex = 2;
            this.rdTextos.TabStop = true;
            this.rdTextos.Text = "textos";
            this.rdTextos.UseVisualStyleBackColor = true;
            // 
            // tabResultats
            // 
            this.tabResultats.AutoScroll = true;
            this.tabResultats.BackColor = System.Drawing.Color.Transparent;
            this.tabResultats.Controls.Add(this.llTextos);
            this.tabResultats.Controls.Add(this.tbJson);
            this.tabResultats.Controls.Add(this.lb);
            this.tabResultats.Controls.Add(this.lbJson);
            this.tabResultats.Location = new System.Drawing.Point(4, 27);
            this.tabResultats.Name = "tabResultats";
            this.tabResultats.Padding = new System.Windows.Forms.Padding(3);
            this.tabResultats.Size = new System.Drawing.Size(1695, 736);
            this.tabResultats.TabIndex = 1;
            this.tabResultats.Text = "resultats";
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1727, 791);
            this.Controls.Add(this.tabPestanyes);
            this.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AWS Rekognition";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbImatge)).EndInit();
            this.tabPestanyes.ResumeLayout(false);
            this.tabImatge.ResumeLayout(false);
            this.tabImatge.PerformLayout();
            this.tabResultats.ResumeLayout(false);
            this.tabResultats.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btExaminar;
        private System.Windows.Forms.PictureBox pbImatge;
        private System.Windows.Forms.OpenFileDialog dlgImatge;
        private System.Windows.Forms.ListBox llTextos;
        private System.Windows.Forms.Label lb;
        private System.Windows.Forms.Label lbJson;
        private System.Windows.Forms.TextBox tbJson;
        private System.Windows.Forms.TabControl tabPestanyes;
        private System.Windows.Forms.TabPage tabImatge;
        private System.Windows.Forms.TabPage tabResultats;
        private System.Windows.Forms.RadioButton rdEmocions;
        private System.Windows.Forms.RadioButton rdTextos;
        private System.Windows.Forms.Button btDetectar;
        private System.Windows.Forms.RadioButton rdFamosos;
    }
}

