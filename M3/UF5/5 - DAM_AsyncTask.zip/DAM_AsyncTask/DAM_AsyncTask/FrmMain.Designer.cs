﻿namespace DAM_AsyncTask
{
    partial class FrmMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btAsync = new System.Windows.Forms.Button();
            this.dlgColor = new System.Windows.Forms.ColorDialog();
            this.btColor = new System.Windows.Forms.Button();
            this.btSync = new System.Windows.Forms.Button();
            this.lbObs = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btAsync
            // 
            this.btAsync.BackColor = System.Drawing.Color.LimeGreen;
            this.btAsync.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btAsync.Location = new System.Drawing.Point(28, 26);
            this.btAsync.Name = "btAsync";
            this.btAsync.Size = new System.Drawing.Size(137, 45);
            this.btAsync.TabIndex = 0;
            this.btAsync.Text = "Async";
            this.btAsync.UseVisualStyleBackColor = false;
            this.btAsync.Click += new System.EventHandler(this.btGo_ClickAsync);
            // 
            // btColor
            // 
            this.btColor.BackColor = System.Drawing.Color.Orange;
            this.btColor.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btColor.Location = new System.Drawing.Point(28, 245);
            this.btColor.Name = "btColor";
            this.btColor.Size = new System.Drawing.Size(137, 45);
            this.btColor.TabIndex = 1;
            this.btColor.Text = "Color";
            this.btColor.UseVisualStyleBackColor = false;
            this.btColor.Visible = false;
            this.btColor.Click += new System.EventHandler(this.btColor_Click);
            // 
            // btSync
            // 
            this.btSync.BackColor = System.Drawing.Color.Teal;
            this.btSync.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSync.ForeColor = System.Drawing.Color.White;
            this.btSync.Location = new System.Drawing.Point(28, 99);
            this.btSync.Name = "btSync";
            this.btSync.Size = new System.Drawing.Size(137, 45);
            this.btSync.TabIndex = 2;
            this.btSync.Text = "Sync";
            this.btSync.UseVisualStyleBackColor = false;
            this.btSync.Click += new System.EventHandler(this.btSync_Click);
            // 
            // lbObs
            // 
            this.lbObs.AutoSize = true;
            this.lbObs.Location = new System.Drawing.Point(24, 179);
            this.lbObs.Name = "lbObs";
            this.lbObs.Size = new System.Drawing.Size(642, 40);
            this.lbObs.TabIndex = 3;
            this.lbObs.Text = "Quina diferència trobes que hi ha si cliques el botó Async o el botó Sync?\r\n\r\n";
            // 
            // FrmMain
            // 
            this.AcceptButton = this.btAsync;
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(845, 346);
            this.Controls.Add(this.lbObs);
            this.Controls.Add(this.btSync);
            this.Controls.Add(this.btColor);
            this.Controls.Add(this.btAsync);
            this.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Exemple Async Task";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btAsync;
        private System.Windows.Forms.ColorDialog dlgColor;
        private System.Windows.Forms.Button btColor;
        private System.Windows.Forms.Button btSync;
        private System.Windows.Forms.Label lbObs;
    }
}

