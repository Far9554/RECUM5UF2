﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DAM_AsyncTask
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        public async Task<Boolean> Esperar()  
        {
            Int32 nseg = 10;

            await Task.Delay(nseg*1000); 
            return true;
        }

        private async Task procesAsincron()
        {
            Task<Boolean> TascaEsperar = Esperar();

            Boolean jaEstic = await TascaEsperar;
            MessageBox.Show("Han passat 10 segons!!!!!!!!!!!!!!!", "Ei!!!!!!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            btAsync.Visible = true;
            btSync.Visible = true;
            btColor.Visible = false;
        }

        private void btGo_ClickAsync(object sender, EventArgs e)
        {
            btAsync.Visible = false;
            btSync.Visible = false;
            btColor.Visible = true;
            procesAsincron();   
        }

        private void btColor_Click(object sender, EventArgs e)
        {
            if (dlgColor.ShowDialog()== DialogResult.OK)
            {
                this.BackColor = dlgColor.Color;
            }
        }

        private void btSync_Click(object sender, EventArgs e)
        {
            btAsync.Visible = false;
            btSync.Visible = false;
            btColor.Visible = true;
            System.Threading.Thread.Sleep(10000);
            MessageBox.Show("Han passat 10 segons!!!!!!!!!!!!!!!", "Ei!!!!!!", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            btAsync.Visible = true;
            btSync.Visible = true;
            btColor.Visible = false;
        }
    }
}
